from response import Response

class Translator() :
    """
    Test translator for the whisperer in darkness. Contains shorter, more debug focussed test phrases
    """
    Launch = Response(
        "Welcome to the whisperer in darkness"
        ,"Launch Reprompt"
        )