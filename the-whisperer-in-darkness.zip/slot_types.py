import enum

class Order(enum.Enum):
    first = 1
    second = 2
    third = 3
    fourth = 4