class Audio():

    Splat = "<audio src='https://s3.amazonaws.com/the-whisperer-in-darkness/splat.mp3'/>"

    octopus_room_error_audio = "<audio src='something'/>"
